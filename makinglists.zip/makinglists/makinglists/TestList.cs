﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MakingLists
{
	internal delegate void TestFun();

	public class TestList
	{
		private readonly Func<IAlgoList<int>> getTheirs;

		public TestList(Func<IAlgoList<int>> getTheirs)
		{
			this.getTheirs = getTheirs;
		}

		private void Assert(int should, int actual)
		{
			if (should != actual)
			{
				Console.WriteLine(should + " != " + actual);
				throw new Exception();
			}
		}
		private void Assert(bool should)
		{
			if (!should)
			{
				throw new Exception();
			}
		}

		public void RunAll()
		{
			List<Tuple<string, Action>> funcs = new List<Tuple<string, Action>>();
			funcs.Add(new Tuple<string, Action>("Add", Add));
			funcs.Add(new Tuple<string, Action>("Add2", Add2));
			funcs.Add(new Tuple<string, Action>("RemoveAt", RemoveAt));
			funcs.Add(new Tuple<string, Action>("RemoveAt2", RemoveAt2));
			funcs.Add(new Tuple<string, Action>("Remove", Remove));
			funcs.Add(new Tuple<string, Action>("Remove2", Remove2));
            funcs.Add(new Tuple<string, Action>("Insert", Insert));
            funcs.Add(new Tuple<string, Action>("Insert2", Insert2));
			foreach (var action in funcs)
			{
				try
				{
					Console.Write("Running " + action.Item1 + " ");
					action.Item2();
					var t = Console.ForegroundColor;
					Console.ForegroundColor = ConsoleColor.DarkGreen;
					Console.WriteLine("Pass");
					Console.ForegroundColor = t;
				}
				catch (Exception)
				{
					var t = Console.ForegroundColor;
					Console.ForegroundColor = ConsoleColor.Red;
					Console.WriteLine("Fail");
					Console.ForegroundColor = t;
				}
			}
		}

		private static readonly Random Rand = new Random();

		private static void ShuffleArray<T>(IAlgoList<T> array)
		{
			for (int i = 0; i < array.Count; i++)
			{
				int randomIndex = Rand.Next(array.Count);
				T tmp = array[i];
				array[i] = array[randomIndex];
				array[randomIndex] = tmp;
			}
		}

		private static void ShuffleArray<T>(IList<T> array)
		{
			for (int i = 0; i < array.Count; i++)
			{
				int randomIndex = Rand.Next(array.Count);
				T tmp = array[i];
				array[i] = array[randomIndex];
				array[randomIndex] = tmp;
			}
		}

		public void Add()
		{
			IAlgoList<int> toTest = getTheirs();
            const int size = 100000;
			for (int i = 0; i < size; i++)
			{
				toTest.Add(i);
			}
			for (int i = 0; i < size; i++)
			{
				Assert(i,toTest[i]);
			}
		}

        //Inserting single value
        public void Insert()
        {
            IAlgoList<int> toTest = getTheirs();
            const int size = 100000;
            int j = 0;
            for (int i = 0; i < size; i++)
            {
                toTest.Insert(i, j);
                j++;
            }
            for (int i = 0; i < size; i++)
            {
                Assert(i, toTest[i]);
            }
        }

        //Inserting a multiple value
        public void Insert2()
        {
            List<int> verify = new List<int>();
            IAlgoList<int> toTest = getTheirs();
            const int size = 100000;
            int j = 0;

            for (int i = 0; i < size; i++)
            {
                verify.Insert(j, i);
                toTest.Insert(j, i);
                j++;
            }
            for (int i = Rand.Next(); i < size; i++)
            {
                int count = 0;
                if (count < 20)
                {
                    int num = Rand.Next();
                    toTest.Insert(num, i);
                    count++;
                }
            }
            for (int i = 0; i < size; i++)
            {
                Assert(verify[i], toTest[i]);
            }
        }

		public void Add2()
		{
			List<int> verify = new List<int>();
			IAlgoList<int> toTest = getTheirs();
            const int size = 100000;
			for (int i = 0; i < size; i++)
			{
				int num = Rand.Next();
				verify.Add(num);
				toTest.Add(num);
			}
			for (int i = 0; i < size; i++)
			{
				Assert(verify[i],toTest[i]);
			}
		}

		public void RemoveAt()
		{
			IAlgoList<int> toTest = getTheirs();
            const int size = 100000;
			for (int i = 0; i < size; i++)
			{
				toTest.Add(i);
			}
			int counter = 0;
			while (toTest.Count > 0)
			{
				toTest.RemoveAt(Rand.Next(toTest.Count));
				counter++;
			}
			Assert(size,counter);
		}

		public void RemoveAt2()
		{
			IAlgoList<int> toTest = getTheirs();
            const int size = 100000;
			for (int i = 0; i < size; i++)
			{
				toTest.Add(i);
			}
			int counter = 0;
			while (toTest.Count > 0)
			{
				toTest.RemoveAt(0);
				counter++;
			}
			Assert(size,counter);
		}

		public void Remove()
		{
			List<int> toRemoveOrder = new List<int>();
			IAlgoList<int> toTest = getTheirs();
            const int size = 100000;
			for (int i = 0; i < size; i++)
			{
				toTest.Add(i);
				toRemoveOrder.Add(i);
			}
			ShuffleArray(toRemoveOrder);
			foreach (int t in toRemoveOrder)
			{
				Assert(toTest.Remove(t));
			}
			Assert(0,toTest.Count);
		}

		public void Remove2()
		{
			IAlgoList<int> toTest = getTheirs();
			const int size = 100000;
			for (int i = 0; i < size; i++)
			{
				toTest.Add(i);
			}
			ShuffleArray(toTest);
			for (int i = 0; i < size; i++)
			{
				Assert(toTest.Remove(i));
			}
			Assert(0,toTest.Count);
		}
	}
}
