﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MakingLists
{
    class MyList<T> : IAlgoList<T>
    {
        private T[] AlgoList;
        private int counter = 0;

        /// <summary>
        /// Testing purposes
        /// </summary>
        public MyList()
		{
            AlgoList = new T[100000];
		}
        /// <summary>
		/// Gets or sets the element at the specified index
		/// </summary>
		/// <param name="index">The zero-based index of the element to get or set</param>
		/// <returns>The element at the specified index</returns>
        public T this[int index]
        {
            get
            {
                return AlgoList[index];
            }
            set
            {
                AlgoList[index] = value;
            }
        }

        /// <summary>
        /// Gets the number of elements contained in the collection
        /// </summary>
        public int Count
        {
            get 
            { 
                return AlgoList.Length;
            }
        }

        /// <summary>
        /// Adds an item to the collection
        /// </summary>
        /// <param name="item">The object to added</param> 
        public void Add(T item)
        {
            AlgoList[counter] = item;
            counter++;
        }

        /// <summary>
        /// Removes all items from the collection
        /// </summary>
        public void Clear()
        {
            AlgoList = new T[Count];
        }

        /// <summary>
        /// Removes the first occurrence of the specified object from the collection
        /// </summary>
        /// <param name="item">item to be removed from collection</param>
        /// <returns>true if item was successfuly removed</returns>
        public bool Remove(T item)
        {
            int x = 0;

            foreach (T element in AlgoList)
            {
                if (!element.Equals(item))
                {
                    x++;
                }
                else
                {
                    RemoveAt(x);
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Removes the item at the specified index
        /// </summary>
        /// <param name="index">The zero-based index of the item to remove</param>
        public void RemoveAt(int index)
        {
            int x = 0;
            T[] StorageList = new T[Count - 1];

            for (int y = 0; y < Count; y++)
            {
                if ( y != index)
                {
                    StorageList[x] = AlgoList[y];
                    x++;
                }
            }
            AlgoList = StorageList;
        }

        /// <summary>
        /// Inserts the item at specified Location in the collection
        /// </summary>
        public void Insert(T item, int index)
        {
            AlgoList[index] = item;
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int x = 0; x < Count; x++)
            {
                //returns the next item in the sequence
                yield return AlgoList[x];
            }
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
