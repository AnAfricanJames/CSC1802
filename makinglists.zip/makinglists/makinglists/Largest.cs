﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MakingLists
{
    class Largest
    {
        public void Go()
        {
            readFile();
        }

        public void readFile()
        {
            string line;
            using (StreamReader read = new StreamReader("input.txt"))
            {
                line = read.ReadLine();
                read.Close();
            }
            if (line != null)
            {
                GetLargestValue(line);
            }
        }

        public void GetLargestValue(String Line)
        {
            String[] numbers = Line.Split(',');
            int LargestNumber = -1;

            foreach (string value in numbers)
            {
                int number = Convert.ToInt32(value);

                if (number > LargestNumber)
                {
                    LargestNumber = number;
                }
            }
            if (LargestNumber != -1)
            {
                WriteFile(LargestNumber);
            }
        }

        public void WriteFile(int largest)
        {
            using (StreamWriter writeFile = new StreamWriter("output.txt"))
            {
                writeFile.Write(largest);
                writeFile.Close();
            }
        }
    }
}
